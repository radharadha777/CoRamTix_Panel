<?php

namespace Pterodactyl\Exceptions\Service\Subuser;

use Pterodactyl\Exceptions\DisplayException;

class ServerSubuserExistsException extends DisplayException
{
}
