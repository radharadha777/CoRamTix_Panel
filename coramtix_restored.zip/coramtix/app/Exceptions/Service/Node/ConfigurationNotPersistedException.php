<?php

namespace Pterodactyl\Exceptions\Service\Node;

use Pterodactyl\Exceptions\DisplayException;

class ConfigurationNotPersistedException extends DisplayException
{
}
