<?php

namespace Pterodactyl\Exceptions;

class AutoDeploymentException extends \Exception
{
}
